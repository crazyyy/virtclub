<?php get_header(); ?>

    <section role="main" class="clearfix">
        <article class="slider">
            <p class="warning">Внимание! Модели в категориях «Избранные» и «ТОП-Модели»  оказывают только платные услуги вирт секс по скайпу и со 100%  гарантией  качества и надежности!!!</p>
            <div class="slider-container">
                <?php echo get_new_royalslider(1); ?>
            </div>
        </article>
        <h1>Топ модели:</h1>
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        <article class="model-looper">
            <a href="">
                <h4>name</h4>
                <img src="<?php echo get_template_directory_uri(); ?>/img/model.jpg" alt="">
                <span>Смотреть анкету</span>
            </a>
        </article><!-- model-looper -->
        
    </section>

<?php get_sidebar(); ?>
<?php get_footer(); ?>